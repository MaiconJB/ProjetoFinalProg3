const express = require('express');
const router = express.Router();

// Rota principal
router.get('/', (req, res) => {
  res.render('index', { error: null });
});

router.post('/login', (req, res) => {
  const usuario = req.body.username;
  const senha = req.body.password;

  if (usuario === 'adm' && senha === 'adm') {
    res.redirect('/cadastro'); // Redireciona se o login for bem-sucedido
  } else {
    res.render('index', { error: 'Usuário ou senha incorretos' });
  }
});

module.exports = router;
