const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Caminho para o arquivo estoque.json
const filePath = path.join(__dirname, '../data/estoque.json');

// Função para ler o estoque do arquivo
function lerEstoque() {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Erro ao ler o arquivo de estoque:', err);
    return [];
  }
}

// Função para escrever o estoque no arquivo
function escreverEstoque(estoque) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(estoque, null, 2), 'utf8');
  } catch (err) {
    console.error('Erro ao escrever no arquivo de estoque:', err);
  }
}

// Página de controle de estoque
router.get('/', (req, res) => {
  const estoque = lerEstoque();
  res.render('estoque', { title: 'Controle de Estoque', estoque });
});

// Rota para adicionar um item ao estoque
router.post('/adicionar', (req, res) => {
  const { itemName, itemQuantity, itemValue } = req.body;
  if (!itemName || !itemQuantity || !itemValue) {
    return res.status(400).json({ error: 'Por favor, preencha todos os campos' });
  }

  const estoque = lerEstoque();
  const item = {
    nome: itemName,
    quantidade: parseInt(itemQuantity),
    valor: parseFloat(itemValue),
  };

  estoque.push(item);
  escreverEstoque(estoque);
  res.json({ message: 'Item adicionado ao estoque com sucesso', estoque });
});

// Rota para remover um item do estoque
router.post('/remover', (req, res) => {
  const { itemName } = req.body;
  if (!itemName) {
    return res.status(400).json({ error: 'Nome do item é obrigatório para remoção' });
  }

  let estoque = lerEstoque();
  estoque = estoque.filter(item => item.nome !== itemName);
  escreverEstoque(estoque);
  res.json({ message: 'Item removido do estoque com sucesso', estoque });
});

// Rota para atualizar um item no estoque
router.post('/atualizar', (req, res) => {
  const { itemName, newQuantity, newValue } = req.body;
  if (!itemName || newQuantity === undefined || newValue === undefined) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
  }

  let estoque = lerEstoque();
  estoque = estoque.map(item =>
    item.nome === itemName ? { ...item, quantidade: parseInt(newQuantity), valor: parseFloat(newValue) } : item
  );
  escreverEstoque(estoque);
  res.json({ message: 'Item atualizado com sucesso', estoque });
});

module.exports = router;
