const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Caminho para o arquivo de estoque JSON
const estoquePath = path.join(__dirname, '../data/estoque.json');

let estoque = [];

// Função para carregar o estoque do arquivo JSON
const loadEstoque = () => {
  try {
    const data = fs.readFileSync(estoquePath, 'utf8');
    estoque = JSON.parse(data);
  } catch (error) {
    estoque = []; // Se o arquivo não existir ou não puder ser lido, inicialize como array vazio
  }
};

// Função para salvar o estoque no arquivo JSON
const saveEstoque = () => {
  fs.writeFileSync(estoquePath, JSON.stringify(estoque, null, 2));
};

// Carregar o estoque ao iniciar o servidor
loadEstoque();

// Rota para adicionar um item ao estoque
router.post('/adicionar', (req, res) => {
  const { itemName, itemQuantity, itemValue } = req.body;
  if (!itemName || !itemQuantity || !itemValue) {
    return res.status(400).json({ error: 'Por favor, preencha todos os campos' });
  }
  const item = { nome: itemName, quantidade: parseInt(itemQuantity), valor: parseFloat(itemValue) };
  estoque.push(item);
  saveEstoque();
  res.json({ message: 'Item adicionado ao estoque com sucesso', estoque });
});

// Rota para carregar a página do estoque
router.get('/', (req, res) => {
  res.render('estoque', { title: 'Controle de Estoque', estoque });
});

module.exports = router;
