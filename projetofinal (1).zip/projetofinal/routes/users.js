var express = require('express');
var router = express.Router();

// Rota de listagem de usuários
router.get('/', function(req, res, next) {
  res.send('Rota de listagem de usuários');
});

module.exports = router;
