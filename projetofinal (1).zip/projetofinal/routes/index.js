const express = require('express');
const router = express.Router();

let usuariosCadastrados = [];
let estoque = [];

// Página inicial de login
router.get('/', (req, res) => {
  res.render('index', { title: 'Login', error: req.query.error || null });
});

// Rota de login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (username === 'adm' && password === 'adm') {
    res.render('cadastro', { title: 'Cadastro', usuariosCadastrados, message: null });
  } else if (username === 'usuarioestoque' && password === '1234') {
    res.render('estoque', { title: 'Controle de Estoque', estoque });
  } else {
    res.redirect('/?error=Usuário ou senha incorretos');
  }
});

// Rota de cadastro de usuário
router.post('/cadastro', (req, res) => {
  const { usuarionovo: usuario, senhanova: senha } = req.body;
  if (usuario && senha) {
    usuariosCadastrados.push({ usuario, senha });
    res.render('cadastro', { title: 'Cadastro', usuariosCadastrados, message: 'Usuário cadastrado com sucesso!' });
  } else {
    res.render('cadastro', { title: 'Cadastro', usuariosCadastrados, error: 'Por favor, preencha todos os campos.' });
  }
});

// Rota para adicionar um item ao estoque
router.post('/estoque/adicionar', (req, res) => {
  const { itemName, itemQuantity, itemValue } = req.body;
  if (!itemName || !itemQuantity || !itemValue) {
    return res.status(400).json({ error: 'Por favor, preencha todos os campos' });
  }
  const item = { nome: itemName, quantidade: parseInt(itemQuantity), valor: parseFloat(itemValue) };
  estoque.push(item);
  res.json({ message: 'Item adicionado ao estoque com sucesso', estoque });
});

// Rota para remover um item do estoque
router.post('/estoque/remover', (req, res) => {
  const { itemName } = req.body;
  if (!itemName) {
    return res.status(400).json({ error: 'Nome do item é obrigatório para remoção' });
  }
  estoque = estoque.filter(item => item.nome !== itemName);
  res.json({ message: 'Item removido do estoque com sucesso', estoque });
});

// Rota para atualizar um item no estoque
router.post('/estoque/atualizar', (req, res) => {
  const { itemName, newQuantity, newValue } = req.body;
  if (!itemName || newQuantity === undefined || newValue === undefined) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
  }
  estoque = estoque.map(item =>
    item.nome === itemName ? { ...item, quantidade: parseInt(newQuantity), valor: parseFloat(newValue) } : item
  );
  res.json({ message: 'Item atualizado com sucesso', estoque });
});

// Página de controle de estoque
router.get('/estoque', (req, res) => {
  res.render('estoque', { title: 'Controle de Estoque', estoque });
});

// Rota de redirecionamento para a página de login
router.get('/voltar', (req, res) => {
  res.redirect('/');
});

module.exports = router;
