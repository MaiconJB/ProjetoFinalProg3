const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const createError = require('http-errors');

const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const estoqueRouter = require('./routes/estoque'); // Adicione esta linha

const app = express();

// Configura o mecanismo de visualização
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Configura middlewares
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Usa os roteadores para a aplicação
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/estoque', estoqueRouter); // Adicione esta linha

// Captura 404 e encaminha para o manipulador de erros
app.use((req, res, next) => {
  next(createError(404));
});

// Manipulador de erros
app.use((err, req, res, next) => {
  // Define as variáveis locais, fornecendo apenas erro em desenvolvimento
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // Renderiza a página de erro
  res.status(err.status || 500);
  res.render('error');
});

// Inicializa o servidor
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

module.exports = app;
